%% Solution to 2D problem with exact solution using SBDF4
% Fourth order Adams-Bashford and fourth order Backward Differentiation
% E.O Asante-Asamani
% 05/04/2023

function [runtime,errorval] = testproblem2_2D_AB4BD4(dt,steps)
 
clc; close all
% dt: time step
% steps: number of interior spatial points in each coordinate direction

%% Model Paramters and initial conditions

% diffusion coefficient
d1 = 1; 

% create nodes
x = linspace(-0.5*pi,0.5*pi,steps+2);
h = x(2)-x(1);
xint = x(2:end-1); yint=xint;
nnodes = steps^2;
nodes = zeros(nnodes,2);

j = 1;
for k = 1 : steps
        for i = 1:steps
               nodes(j,:) = [xint(i) yint(k)];
            j = j+1;
        end
end

% discretize time interval
T = 1;
t = 0:dt:T; tlen = length(t);

% initial condition for w_old(continuous)
w_old = zeros(nnodes,1);
for i = 1: nnodes
 pn = nodes(i,:); % extract point
 xn = pn(1);
 yn = pn(2);
 w_old(i) = cos(xn)*cos(yn);
end

%plot initial condition
% Uinit = zeros(steps+2);
% Uinit(2:steps+1,2:steps+1) = reshape(w_old,steps,steps);
% y = x;
% figure(1)
% surf(x,y,Uinit')
% xlabel('x')
% ylabel('y')
% zlabel('U')
% title('\bf\fontsize{20} Numerical Solution ')
% colorbar


%%  Matrix Assembly

% Formulate system matrices 4th order with 4th order extrapolation
r2=d1/(12*h^2);
e = ones(steps,1); Id = speye(nnodes);I = eye(steps);
As = spdiags([-e 16*e -30*e 16*e -e], -2:2, steps, steps); % finite difference diffusion operator
As(1,1) =  -20;
As(end,end) = -20;
As(1,2) = 6;
As(end,end-1) = 6;
As(1,3) = 4;
As(end,end-2) = 4;
As(1,4) = -1;
As(end,end-3) =-1;
As =-r2*As; 
A1 = kron(I,As); A2 = kron(As,I);
A =-( A1+A2);


% Create matrices for solving linear system
k = dt/2000;
M1 = (Id-k*A);
% M2 = (3*Id - 2*k*A); 
% M3 = (11*Id - 6*k*A);
M4 = (25*Id - 12*dt*A);

[L1,U1] = lu(M1); [L4,U4] = lu(M4);
%[L2,U2] = lu(M2); [L3,U3] = lu(M3); 
%% Time Evolution
%hw = waitbar(0,'Simulating...');

tic

% Generate initial solution values with SBDF with very small time step
timep = linspace(0,3*dt,6001);
tlenp = length(timep);

w_olds=w_old;
F_old = F(w_old);

for j = 2:tlenp  
% SBDF1
F_olds = F(w_olds);
w_olds = L1\(w_olds + k*F_olds);
w_olds = U1\w_olds;
    % store corresponding intermediate solutions
    if abs(timep(j)-dt)<k
        w_old1 = w_olds;
        F_old1 = F(w_old1);
    elseif abs(timep(j)-2*dt)<k
         w_old2 = w_olds;
         F_old2 = F(w_old2);
    end
end
 w_old3 = w_olds;

% % Use successive IMEX methods
% % SBDF1
% F_olds = F(w_olds);
% w_olds = L1\(w_olds + k*F_olds);
% w_olds1 = U1\w_olds;
% 
% % SBDF2
%   F_olds1 = F(w_olds1);
%   w_olds2 = L2\(4*w_olds1- w_olds + k*( 4*F_olds1 - 2*F_olds));
%   w_olds2 = U2\w_olds2;
%   
% 
% for j = 4:tlenp
%   % SBDF3
%   F_olds2 = F(w_olds2);
%   w_olds2 = L3\(18*w_olds2- 9*w_olds1 +2*w_olds+ k*( 18*F_olds2 - 18*F_olds1+6*F_olds));
%   w_olds2 = U3\w_olds2;
% 
%     % store corresponding intermediate solutions
%     if abs(timep(j)-dt)<k
%         w_old1 = w_olds2;
%         F_old1 = F(w_old1);
%     elseif abs(timep(j)-2*dt)<k
%          w_old2 = w_olds2;
%          F_old2 = F(w_old2);
%     end
% end
%  w_old3 = w_olds2;
 

for i = 5:tlen   
% SBDF4
F_old3 = F(w_old3); 
w_old4 = L4\(48*w_old3- 36*w_old2 + 16*w_old1-3*w_old+ dt*( 48*F_old3 - 72*F_old2 +48*F_old1-12*F_old));
w_old4 = U4\w_old4;

% Update solution
w_old=w_old1;
w_old1=w_old2;
w_old2 = w_old3;
w_old3 = w_old4;

% Update function values
F_old = F_old1;
F_old1 = F_old2;
F_old2 = F_old3;
end

runtime = toc;
%%
% Compute exact solution
u_exact = zeros(nnodes,1);
for p = 1:nnodes
    xp = nodes(p,1);
    yp = nodes(p,2);
    u_exact(p) = cos(xp)*cos(yp)*exp(-3*T);
end

% Return maximum error
 errorval = max(abs((u_exact-w_old4)));

%% Plot numerical solution
% U = zeros(steps+2);
% U(2:steps+1,2:steps+1) = reshape(w_old4,steps,steps);
% y = x;
% figure(2)
% surf(x,y,U')
% xlabel('x')
% ylabel('y')
% zlabel('U')
% title('\bf\fontsize{20} Numerical Solution ')
% colorbar
% % 
% % Plot exact solution
% Uexact=zeros(steps+2);
% Uexact(2:steps+1,2:steps+1) = reshape(u_exact,steps,steps);
% y = x;
% figure(3)
% surf(x,y,Uexact')
% xlabel('x')
% ylabel('y')
% zlabel('U')
% title('\bf\fontsize{20} Exact Solution ')
% colorbar



% % % Plot computational error 
% 
% Uerror=zeros(steps+2);
% u_error = abs(u_exact-w_old);
% Uerror(2:steps+1,2:steps+1) = reshape(u_error,steps,steps);
% y = x;
% figure(4)
% surf(x,y,Uerror')
% xlabel('x')
% ylabel('y')
% zlabel('U')
% title('\bf\fontsize{20} Numerical Error')
% colorbar



%****************function calls**************************************
function Fr = F(u)
    Fr = -u;
end


end