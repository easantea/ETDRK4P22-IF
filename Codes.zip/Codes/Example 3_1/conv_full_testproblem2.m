% Experiment to compute rate of convergence of ETDRK4P22-IF in comparison with
% other ETD schemes for Example 1 in manuscript
% March 2024

clc;clear
% Time steps
k1=0.1;k2=0.05;k3=0.025;k4=0.0125;k5 =0.00625;


% Mesh size
h1=40; h2=80; h3=160; h4=320;
step = [k1,k2,k3,k4];space=[h1,h2,h3,h4];

%% results for ETDRK4P22 
[runtime1,error1] = testproblem2_2D_ETDRK4P22(k1,h1);
[runtime2,error2] = testproblem2_2D_ETDRK4P22(k2,h2);
[runtime3,error3] = testproblem2_2D_ETDRK4P22(k3,h3);
[runtime4,error4] = testproblem2_2D_ETDRK4P22(k4,h4);

TimeRK4P22=[runtime1,runtime2,runtime3,runtime4];
[convRK4P22,errorRK4P22]=conv_testproblem2(error1,error2,error3,error4,step);

%% results for ETDRDP-IF
[runtime1,error1] = testproblem2_2D_ETDRDP_split(k1,h1);
[runtime2,error2] = testproblem2_2D_ETDRDP_split(k2,h2);
[runtime3,error3] = testproblem2_2D_ETDRDP_split(k3,h3);
[runtime4,error4] = testproblem2_2D_ETDRDP_split(k4,h4);

TimeRDPIF=[runtime1,runtime2,runtime3,runtime4];
[convRDPIF,errorRDPIF]=conv_testproblem2(error1,error2,error3,error4,step);

%% results for ETDRK4P22IF 
[runtime1,error1] =  testproblem2_2D_ETDRK4P22_IF_Serial(k1,h1);
[runtime2,error2] =  testproblem2_2D_ETDRK4P22_IF_Serial(k2,h2);
[runtime3,error3] =  testproblem2_2D_ETDRK4P22_IF_Serial(k3,h3);
[runtime4,error4] =  testproblem2_2D_ETDRK4P22_IF_Serial(k4,h4);

TimeRK4P22IF=[runtime1,runtime2,runtime3,runtime4];
[convRK4P22IF,errorRK4P22IF]=conv_testproblem2(error1,error2,error3,error4,step);

%% results for SBDF4
[runtime1,error1] =  testproblem2_2D_AB4BD4(k1,h1);
[runtime2,error2] =  testproblem2_2D_AB4BD4(k2,h2);
[runtime3,error3] =  testproblem2_2D_AB4BD4(k3,h3);
[runtime4,error4] =  testproblem2_2D_AB4BD4(k4,h4);

TimeSBDF4=[runtime1,runtime2,runtime3,runtime4];
[convSBDF4,errorSBDF4]=conv_testproblem2(error1,error2,error3,error4,step);

%% Generate efficiency and convergence plots
 Time_mat = [TimeRDPIF;TimeRK4P22;TimeRK4P22IF;TimeSBDF4];
 Error_mat = [errorRDPIF;errorRK4P22;errorRK4P22IF;errorSBDF4];
  
 efficiency_plot_testproblem2(Time_mat,Error_mat)
 convergence_plot_testproblem2(step,Error_mat)

%% Display results
fprintf('\n Results for ETDRDPIF\n')
fprintf('k             h            error        conv       Time \n');
for i = 1:4
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),pi/(space(i)),errorRDPIF(i),convRDPIF(i),TimeRDPIF(i))
end
fprintf(' Results for ETDRK2P22\n')
fprintf('k             h            error        conv       Time \n');
for i = 1:4
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),pi/space(i),errorRK4P22(i),convRK4P22(i),TimeRK4P22(i))
end
fprintf(' Results for ETDRK4P22IF\n')
fprintf('k             h            error        conv       Time \n');
for i = 1:4
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),pi/space(i),errorRK4P22IF(i),convRK4P22IF(i),TimeRK4P22IF(i))
end
fprintf(' Results for SBDF4\n')
fprintf('k             h            error        conv       Time \n');
for i = 1:4
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),pi/space(i),errorSBDF4(i),convSBDF4(i),TimeSBDF4(i))
end
