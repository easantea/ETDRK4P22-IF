% Experiment to compute rate of convergence of ETDRK4P22-IF in comparison with
% fourth order ETD schemes for non-smooth enzyme kinetics 
% March 2024

clc;clear
% Time steps
k1=0.1;k2=0.05;k3=0.025;k4=0.0125;k5 =0.00625;

% Mesh size
h1=19; h2=h1; h3=h1; h4=h1; h5=h1;

step = [k1,k2,k3,k4];space=[h1,h2,h3,h4];

%% results for ETDRK4P22 
[runtime1,soln1] = enzymekinetics_2DS4_ETDRK4P22(k1,h1);
[runtime2,soln2] = enzymekinetics_2DS4_ETDRK4P22(k2,h2);
[runtime3,soln3] = enzymekinetics_2DS4_ETDRK4P22(k3,h3);
[runtime4,soln4] = enzymekinetics_2DS4_ETDRK4P22(k4,h4);
[runtime5,soln5] = enzymekinetics_2DS4_ETDRK4P22(k5,h5);

TimeRK4P22=[runtime1,runtime2,runtime3,runtime4];
[convRK4P22,errorRK4P22]=conv_ekinetics_finegrid(soln1,soln2,soln3,soln4,soln5,step);

%% results for ETDRK4P22 
[runtime1,soln1] = enzymekinetics_2DS4_ETDRK4P22s(k1,h1);
[runtime2,soln2] = enzymekinetics_2DS4_ETDRK4P22s(k2,h2);
[runtime3,soln3] = enzymekinetics_2DS4_ETDRK4P22s(k3,h3);
[runtime4,soln4] = enzymekinetics_2DS4_ETDRK4P22s(k4,h4);
[runtime5,soln5] = enzymekinetics_2DS4_ETDRK4P22s(k5,h5);

TimeRK4P22s=[runtime1,runtime2,runtime3,runtime4];
[convRK4P22s,errorRK4P22s]=conv_ekinetics_finegrid(soln1,soln2,soln3,soln4,soln5,step);

%% results for ETDRK4P22-IF 
[runtime1,soln1] = enzymekinetics_2DS4_ETDRK4P22_IF_Serial(k1,h1);
[runtime2,soln2] = enzymekinetics_2DS4_ETDRK4P22_IF_Serial(k2,h2);
[runtime3,soln3] = enzymekinetics_2DS4_ETDRK4P22_IF_Serial(k3,h3);
[runtime4,soln4] = enzymekinetics_2DS4_ETDRK4P22_IF_Serial(k4,h4);
[runtime5,soln5] = enzymekinetics_2DS4_ETDRK4P22_IF_Serial(k5,h5);

TimeRK4P22IF=[runtime1,runtime2,runtime3,runtime4];
[convRK4P22IF,errorRK4P22IF]=conv_ekinetics_finegrid(soln1,soln2,soln3,soln4,soln5,step);

%% results for ETDRK4P22-IFs 
[runtime1,soln1] = enzymekinetics_2DS4_ETDRK4P22_IF_Smooth(k1,h1);
[runtime2,soln2] = enzymekinetics_2DS4_ETDRK4P22_IF_Smooth(k2,h2);
[runtime3,soln3] = enzymekinetics_2DS4_ETDRK4P22_IF_Smooth(k3,h3);
[runtime4,soln4] = enzymekinetics_2DS4_ETDRK4P22_IF_Smooth(k4,h4);
[runtime5,soln5] = enzymekinetics_2DS4_ETDRK4P22_IF_Smooth(k5,h5);

TimeRK4P22IFs=[runtime1,runtime2,runtime3,runtime4];
[convRK4P22IFs,errorRK4P22IFs]=conv_ekinetics_finegrid(soln1,soln2,soln3,soln4,soln5,step);

%% results for SBDF4
[runtime1,soln1] = enzymekinetics_2DS4_SBDF4(k1,h1);
[runtime2,soln2] = enzymekinetics_2DS4_SBDF4(k2,h2);
[runtime3,soln3] = enzymekinetics_2DS4_SBDF4(k3,h3);
[runtime4,soln4] = enzymekinetics_2DS4_SBDF4(k4,h4);
[runtime5,soln5] = enzymekinetics_2DS4_SBDF4(k5,h5);

TimeSBDF4=[runtime1,runtime2,runtime3,runtime4];
[convSBDF4,errorSBDF4]=conv_ekinetics_finegrid(soln1,soln2,soln3,soln4,soln5,step);
%% Produce Efficiency and Convergence plots

%ETD Comparison
 Time_mat = [TimeRK4P22;TimeRK4P22s;TimeRK4P22IF;TimeRK4P22IFs;TimeSBDF4];
 Error_mat = [errorRK4P22;errorRK4P22s;errorRK4P22IF;errorRK4P22IFs;errorSBDF4];

efficiency_plot_ekinetics_nsmooth(Time_mat,Error_mat)
convergence_plot_ekinetics_nsmooth(step,Error_mat)
%% Display results

fprintf(' Results for ETDRK2P22\n')
fprintf('k             h            error        conv       Time \n');
for i = 1:4
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),pi/space(i),errorRK4P22(i),convRK4P22(i),TimeRK4P22(i))
end
fprintf(' Results for ETDRK2P22s\n')
fprintf('k             h            error        conv       Time \n');
for i = 1:4
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),pi/space(i),errorRK4P22s(i),convRK4P22s(i),TimeRK4P22s(i))
end
fprintf(' Results for ETDRK4P22IF\n')
fprintf('k             h            error        conv       Time \n');
for i = 1:4
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),pi/space(i),errorRK4P22IF(i),convRK4P22IF(i),TimeRK4P22IF(i))
end
fprintf(' Results for ETDRK4P22IFs\n')
fprintf('k             h            error        conv       Time \n');
for i = 1:4
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),pi/space(i),errorRK4P22IFs(i),convRK4P22IFs(i),TimeRK4P22IFs(i))
end
fprintf(' Results for SBDF4\n')
fprintf('k             h            error        conv       Time \n');
for i = 1:4
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),pi/space(i),errorSBDF4(i),convSBDF4(i),TimeSBDF4(i))
end
