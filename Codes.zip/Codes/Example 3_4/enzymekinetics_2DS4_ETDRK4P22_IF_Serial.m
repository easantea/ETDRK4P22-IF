%% Solution to 2D enzyme kinetics using ETDRK4P22_IF without presmoothing and 
% Fourth order central differencing in space
% E.O Asante-Asamani
% 05/06/2023

function [runtime,w_old] = enzymekinetics_2DS4_ETDRK4P22_IF_Serial(dt,steps)
 
clc; close all
% dt: time step
% steps: number of interior spatial points in each coordinate direction

%% Model Paramters and initial conditions

% diffusion coefficient
d1 = 1; 

% create nodes
x = linspace(0,1,steps+2);
h = x(2)-x(1);
xint = x(2:end-1); yint=xint;
nnodes = steps^2;
nodes = zeros(nnodes,2);

j = 1;
for k = 1 : steps
        for i = 1:steps
               nodes(j,:) = [xint(i) yint(k)];
            j = j+1;
        end
end

% discretize time interval
t = 0:dt:1; tlen = length(t);

% initial condition for w_old(continuous)
% w_old = zeros(nnodes,1);
% for i = 1: nnodes
%  pn = nodes(i,:); % extract point
%  xn = pn(1);
%  yn = pn(2);
%  w_old(i) = sin(pi*xn)*sin(pi*yn);
% end

% Discontinuous
w_old = ones(nnodes,1);

% w_old = zeros(nnodes,1);
% for i = 1:nnodes
%     if nodes(i,2) < 0.5
%         w_old(i)=-1;
%     else
%         w_old(i)=1;
%     end
% end

%%  Matrix Assembly
% Poles and weights of partial fraction decomposition
c1 = -3+sqrt(3)*1i; w11 = -6-6*sqrt(3)*1i;
c2 = -6+2*sqrt(3)*1i; w21 = -0.5-(5*sqrt(3)/6)*1i;
w31 = -(sqrt(3)/6)*1i; w41 = 0.5 + (sqrt(3)/6)*1i;
w51 = -(sqrt(3)/12)*1i;

% Formulate system matrices
r2=d1/(12*h^2);
e = ones(steps,1); Id = speye(nnodes);I = eye(steps);
As = spdiags([-e 16*e -30*e 16*e -e], -2:2, steps, steps); % finite difference diffusion operator
As(1,1) =  -20;
As(end,end) = -20;
As(1,2) = 6;
As(end,end-1) = 6;
As(1,3) = 4;
As(end,end-2) = 4;
As(1,4) = -1;
As(end,end-3) =-1;
As =-r2*As; 
A1 = kron(I,As); A2 = kron(As,I); 


% Create matrices for solving linear system
M1 = (dt*A1 - c1*Id); M2 = (dt*A1 - c2*Id); M3 = (dt*A2 - c1*Id); M4 = (dt*A2 - c2*Id);
%% Time Evolution
%hw = waitbar(0,'Simulating...');
[L1,U1] = lu(M1); [L2,U2] = lu(M2); [L3,U3] = lu(M3); [L4,U4] = lu(M4);

tic
for i = 2:tlen
% Stage 1 Solve for an
Fold = F(w_old); 
an1 = L4\(2*w11*w_old + 24*w51*dt*Fold);
an1 = U4\an1;
an2 = w_old + 2*real(an1);
an3 = L2\(2*w11*an2);
an3 = U2\an3;
an = an2 + 2*real(an3);
Fan = F(an);

% Stage 2 Solve for bn
bn1 = L4\(2*w11*w_old);
bn1 = U4\bn1;
bn2 = L4\(24*w51*dt*Fan);
bn2 = U4\bn2;
bn3 = w_old + 2*real(bn1);
bn4 = L2\(2*w11*bn3);
bn4 = U2\bn4;
bn = bn3 + 2*real(bn4)+ 2*real(bn2);
Fbn = F(bn);

% Stage 3 Solve for cn
% Processor 1
cn1 = L4\(2*w11*an + 48*w51*dt*Fbn);
cn1 = U4\cn1;
% Processor 2
cn2 = L4\(24*w51*dt*Fold);
cn2 = U4\cn2;
cnstar1 = an + 2*real(cn1);
cnstar2 = 2*real(cn2);
% Processor 1
cn3 = L2\(2*w11*cnstar1);
cn3 = U2\cn3;
% Processor 2
cn4 = L1\(w11*cnstar2);
cn4 = U1\cn4;
cn = cnstar1 + 2*real(cn3)- (cnstar2 + 2*real(cn4));
Fcn = F(cn);

% Update future solution
Gn = Fan+Fbn;
% Processor 1
wn1 = L3\(w11*w_old + w21*dt*Fold);
wn1 = U3\wn1;
% Processor 2
wn2 = L3\(4*w31*dt*Gn);
wn2 = U3\wn2;
% Processor 3
wn3 = L3\(w41*dt*Fcn);
wn3 = U3\wn3;
wstar1 = w_old + 2*real(wn1);
wstar2 = 2*real(wn2);
wstar3 = 2*real(wn3);
% Processor 1
wn4 = L1\(w11*wstar1);
wn4 = U1\wn4;
% Processor 2
wn5 = L2\(2*w11*wstar2);
wn5 = U2\wn5;

w_old = wstar1 + wstar2 + wstar3 + 2*real(wn4) + 2*real(wn5);

end

runtime = toc;
%% Plots
% U = zeros(steps+2);
% U(2:steps+1,2:steps+1) = reshape(w_old,steps,steps);
% y = x;
% figure
% surf(x,y,U')
% xlabel('x')
% ylabel('y')
% zlabel('U')
% %title('\bf\fontsize{20} U solution ')
%  colorbar


%****************function calls**************************************
function Fr = F(u)
 Fr = -u./(1+u);
end


end