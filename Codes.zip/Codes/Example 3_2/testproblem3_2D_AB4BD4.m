%% Solution to 2D problem with exact solution using SBDF4
% Fourth order Adams-Bashford and fourth order Backward Differentiation
% E.O Asante-Asamani
% 03/12/2023

function [runtime,errorval] = testproblem3_2D_AB4BD4(dt,steps)
 
clc; close all
% dt: time step
% steps: number of spatial points in each coordinate direction

%% Model Paramters and initial conditions

% diffusion coefficient
d1 = 1; 

% create nodes
x = linspace(-pi,pi,steps);
h = x(2)-x(1);
xint = x; yint=x;
nnodes = steps^2;
nodes = zeros(nnodes,2);

j = 1;
for k = 1 : steps
        for i = 1:steps
               nodes(j,:) = [xint(i) yint(k)];
            j = j+1;
        end
end

% discretize time interval
T = 1;
t = 0:dt:T; tlen = length(t);

% initial condition for w_old(continuous)
w_old = zeros(nnodes,1);
for i = 1: nnodes
 pn = nodes(i,:); % extract point
 xn = pn(1);
 yn = pn(2);
 w_old(i) = cos(xn)*cos(yn);
end



%%  Matrix Assembly
 
% Formulate system matrices 4th order with 4th order extrapolation
r2=d1/(12*h^2);
e = ones(steps,1); Id = speye(nnodes);I = eye(steps);
As = spdiags([-e 16*e -30*e 16*e -e], -2:2, steps, steps); % finite difference diffusion operator
% first and last row
As(1,2) =  32;
As(end,end-1) = 32;
As(1,3) = -2;
As(end,end-2) = -2;

% second and second to last row
As(2,2) = -31;
As(end-1,end-1) = -31;
As =-r2*As; 
A1 = kron(I,As); A2 = kron(As,I);
A = -(A1+A2);


% Create matrices for solving linear system
k = dt/2000;
M1 = (Id-k*A);
M4 = (25*Id - 12*dt*A);

[L1,U1] = lu(M1); [L4,U4] = lu(M4);
%% Time Evolution
tic

% Generate initial solution values with SBDF with very small time step
timep = linspace(0,3*dt,6001);
tlenp = length(timep);

w_olds=w_old;
F_old = F(w_old);

for j = 2:tlenp  
% SBDF1
F_olds = F(w_olds);
w_olds = L1\(w_olds + k*F_olds);
w_olds = U1\w_olds;
    % store corresponding intermediate solutions
    if abs(timep(j)-dt)<k
        w_old1 = w_olds;
        F_old1 = F(w_old1);
    elseif abs(timep(j)-2*dt)<k
         w_old2 = w_olds;
         F_old2 = F(w_old2);
    end
end
 w_old3 = w_olds;

for i = 5:tlen   
% SBDF4
F_old3 = F(w_old3); 
w_old4 = L4\(48*w_old3- 36*w_old2 + 16*w_old1-3*w_old+ dt*( 48*F_old3 - 72*F_old2 +48*F_old1-12*F_old));
w_old4 = U4\w_old4;

% Update solution
w_old=w_old1;
w_old1=w_old2;
w_old2 = w_old3;
w_old3 = w_old4;

% Update function values
F_old = F_old1;
F_old1 = F_old2;
F_old2 = F_old3;
end

runtime = toc;

%% Compute exact solution
u_exact = zeros(nnodes,1);
for p = 1:nnodes
    xp = nodes(p,1);
    yp = nodes(p,2);
    u_exact(p) = cos(xp)*cos(yp)*exp(-3*T);
end

% Return maximum error
 errorval = max(abs((u_exact-w_old4)));


%% Plot numerical solution

% U = reshape(w_old4,steps,steps);
% y = x;
% figure(2)
% surf(x,y,U')
% xlabel('x')
% ylabel('y')
% zlabel('U')
% title('\bf\fontsize{20} Numerical Solution ')
% colorbar
% 
% % Plot exact solution
% 
% Uexact = reshape(u_exact,steps,steps);
% y = x;
% figure(3)
% surf(x,y,Uexact')
% xlabel('x')
% ylabel('y')
% zlabel('U')
% title('\bf\fontsize{20} Exact Solution ')
% colorbar

%%
%****************function calls**************************************
function Fr = F(u)
Fr = -u;
end


end